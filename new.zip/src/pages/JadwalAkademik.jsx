import PropTypes from "prop-types";
import { academicCalendar } from "../../data/academicCalendar";
import ScheduleCard from "../components/ScheduleCard";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import { useState, useEffect } from "react";

function AllSchedules() {
  const navigate = useNavigate();

  // State untuk mengontrol visibilitas tombol
  const [scrollButtons, setScrollButtons] = useState({});

  const handleScroll = (containerId, direction) => {
    const container = document.getElementById(containerId);
    if (!container) return;

    // Dapatkan lebar card pertama sebagai referensi
    const firstCard = container.querySelector("[data-card]");
    if (!firstCard) return;

    // Dapatkan lebar card + gap (gap-4 = 1rem = 16px, gap-6 = 1.5rem = 24px)
    const gap = window.innerWidth >= 640 ? 24 : 16; // sm:gap-6 vs gap-4
    const scrollAmount = firstCard.offsetWidth + gap;

    // Scroll ke kiri atau kanan sesuai lebar card
    container.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth",
    });
  };

  // Fungsi untuk mengecek scroll position
  const checkScroll = (containerId) => {
    const container = document.getElementById(containerId);
    if (container) {
      const { scrollLeft, scrollWidth, clientWidth } = container;
      const hasOverflow = scrollWidth > clientWidth + 1;

      setScrollButtons((prev) => ({
        ...prev,
        [containerId]: {
          left: scrollLeft > 0,
          right: hasOverflow && scrollLeft < scrollWidth - clientWidth - 1,
        },
      }));
    }
  };

  // Fungsi untuk inisialisasi scroll check
  const initScrollCheck = (containerId) => {
    const container = document.getElementById(containerId);
    if (container) {
      // Check initial overflow dengan lebih akurat
      const hasOverflow = container.scrollWidth > container.clientWidth + 1;

      // Update button state
      setScrollButtons((prev) => ({
        ...prev,
        [containerId]: {
          left: false,
          right: hasOverflow,
        },
      }));

      // Add scroll listener jika ada overflow
      if (hasOverflow) {
        container.addEventListener("scroll", () => checkScroll(containerId));
      }
    }
  };

  // Effect untuk inisialisasi scroll check untuk semua container
  useEffect(() => {
    academicCalendar.schedules.forEach((_, index) => {
      const containerId = `scroll-container-${index}`;
      initScrollCheck(containerId);
    });

    // Cleanup listeners on unmount
    return () => {
      academicCalendar.schedules.forEach((_, index) => {
        const container = document.getElementById(`scroll-container-${index}`);
        if (container) {
          container.removeEventListener("scroll", () =>
            checkScroll(`scroll-container-${index}`)
          );
        }
      });
    };
  }, []);

  // Fungsi untuk menggabungkan tanggal semester
  const getCombinedDate = (item) => {
    if (item.oddSemester !== "-" && item.evenSemester !== "-") {
      return `Ganjil: ${item.oddSemester}\nGenap:  ${item.evenSemester}`;
    }
    return item.oddSemester !== "-"
      ? `Ganjil: ${item.oddSemester}`
      : `Genap:  ${item.evenSemester}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <Navbar />
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 mb-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                {academicCalendar.title}
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {academicCalendar.year}
              </p>
            </div>
            <button
              onClick={() => navigate("/home")}
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 hover:text-custom-blue dark:hover:text-custom-blue transition-colors duration-200"
            >
              <span className="mr-2">←</span>
              Kembali ke Dashboard
            </button>
          </div>
        </div>

        {/* Schedule Sections */}
        <div className="space-y-4 sm:space-y-8">
          {academicCalendar.schedules.map((schedule, index) => {
            const containerId = `scroll-container-${index}`;
            const showButtons = scrollButtons[containerId] || {
              left: false,
              right: false,
            };

            return (
              <div
                key={schedule.category}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 p-4 sm:p-6"
              >
                <div className="flex items-center space-x-3 mb-4 sm:mb-8">
                  <div className="p-2 bg-custom-blue/10 rounded-xl">
                    <i className="fas fa-calendar-alt text-custom-blue"></i>
                  </div>
                  <h2 className="text-lg sm:text-xl font-semibold text-gray-800 dark:text-white">
                    {schedule.category}. {schedule.name}
                  </h2>
                </div>

                {/* Cards Container with Navigation Buttons */}
                <div className="relative group">
                  {/* Previous Button */}
                  {showButtons.left && (
                    <button
                      onClick={() => handleScroll(containerId, "left")}
                      className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 sm:-translate-x-4 z-10 
                        bg-white dark:bg-gray-800 rounded-full p-1.5 sm:p-2 shadow-md border border-gray-200 
                        dark:border-gray-700 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity
                        hover:bg-gray-50 dark:hover:bg-gray-700
                        flex items-center justify-center"
                      aria-label="Scroll left"
                    >
                      <i className="fas fa-chevron-left text-sm sm:text-base text-gray-600 dark:text-gray-300"></i>
                    </button>
                  )}

                  {/* Scroll Container */}
                  <div
                    id={containerId}
                    className="flex overflow-x-auto pb-6 px-4 -mx-4 scrollbar-hide snap-x snap-mandatory"
                  >
                    <div className="flex gap-4 sm:gap-6">
                      {schedule.items.map((item) => (
                        <div
                          key={item.id}
                          className="flex flex-col gap-4 sm:gap-6 flex-shrink-0 snap-start"
                        >
                          {item.subitems ? (
                            <>
                              <div data-card>
                                <ScheduleCard
                                  title={item.name}
                                  date=""
                                  isParent={true}
                                />
                              </div>
                              {item.subitems.map((subitem) => (
                                <div key={subitem.id} data-card>
                                  <ScheduleCard
                                    title={subitem.name}
                                    date={getCombinedDate(subitem)}
                                  />
                                </div>
                              ))}
                            </>
                          ) : (
                            <div data-card>
                              <ScheduleCard
                                title={item.name}
                                date={getCombinedDate(item)}
                              />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Next Button */}
                  {showButtons.right && (
                    <button
                      onClick={() => handleScroll(containerId, "right")}
                      className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 sm:translate-x-4 z-10 
                        bg-white dark:bg-gray-800 rounded-full p-1.5 sm:p-2 shadow-md border border-gray-200 
                        dark:border-gray-700 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity
                        hover:bg-gray-50 dark:hover:bg-gray-700
                        flex items-center justify-center"
                      aria-label="Scroll right"
                    >
                      <i className="fas fa-chevron-right text-sm sm:text-base text-gray-600 dark:text-gray-300"></i>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Hide scrollbar styles */}
      <style jsx global>{`
        /* For Webkit browsers like Chrome/Safari */
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }

        /* For IE, Edge and Firefox */
        .scrollbar-hide {
          -ms-overflow-style: none; /* IE and Edge */
          scrollbar-width: none; /* Firefox */
        }
      `}</style>
    </div>
  );
}

AllSchedules.propTypes = {
  onBack: PropTypes.func,
};

export default AllSchedules;
