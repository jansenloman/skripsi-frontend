import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";

const SchedulePreview = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { scheduleData } = location.state || {};
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Handle ketika user memilih resolusi konflik
  const handleConflictResolution = async (conflictIndex, suggestion) => {
    setIsLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        "http://localhost:3000/api/schedule/resolve-conflict",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            originalSchedule: scheduleData,
            conflictIndex,
            selectedResolution: suggestion,
          }),
        }
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Gagal menyelesaikan konflik");
      }

      // Update schedule dengan hasil resolusi
      navigate("/schedule-preview", { state: { scheduleData: data.schedule } });
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle save schedule
  const handleSave = async () => {
    setIsLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        "http://localhost:3000/api/schedule/save-schedule",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            schedule: scheduleData.schedule,
          }),
        }
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Gagal menyimpan jadwal");
      }

      navigate("/home", {
        state: { message: "Jadwal berhasil disimpan!" },
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (!scheduleData) {
    navigate("/generate-schedule");
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h1 className="text-2xl font-bold mb-6">Preview Jadwal</h1>

          {error && (
            <div className="mb-4 bg-red-100 text-red-700 p-3 rounded-md">
              {error}
            </div>
          )}

          {scheduleData.hasConflict ? (
            // Tampilkan konflik dan opsi resolusi
            <div className="mb-6">
              <div className="bg-yellow-100 p-4 rounded-md">
                <h2 className="text-lg font-semibold text-yellow-800 mb-4">
                  Konflik Jadwal Terdeteksi
                </h2>
                {scheduleData.conflicts.map((conflict, index) => (
                  <div key={index} className="mb-4 border-b pb-4">
                    <p className="font-medium">
                      {conflict.day} ({conflict.time})
                    </p>
                    <div className="mt-2">
                      <p className="font-medium">Kegiatan yang bentrok:</p>
                      <ul className="list-disc pl-5 mb-2">
                        {conflict.tasks.map((task, idx) => (
                          <li key={idx} className="text-gray-700">
                            {task.description}
                            {task.isFixed && (
                              <span className="ml-2 text-xs bg-gray-200 px-2 py-1 rounded">
                                Jadwal Tetap
                              </span>
                            )}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="mt-4">
                      <p className="font-medium mb-2">Saran perubahan:</p>
                      {conflict.suggestions.map((suggestion, idx) => (
                        <div key={idx} className="mb-2">
                          <label className="flex items-start space-x-2">
                            <input
                              type="radio"
                              name={`conflict-${index}`}
                              onChange={() =>
                                handleConflictResolution(index, suggestion)
                              }
                              className="mt-1"
                            />
                            <div>
                              <p>{suggestion.task}</p>
                              <p className="text-sm text-gray-600">
                                Waktu: {suggestion.alternativeTime}
                              </p>
                              <p className="text-sm text-gray-500">
                                {suggestion.reason}
                              </p>
                            </div>
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            // Tampilkan jadwal tanpa konflik
            <div className="space-y-6">
              {scheduleData.schedule.map((day, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <h2 className="text-lg font-semibold mb-3">{day.day}</h2>
                  <ul className="space-y-2">
                    {day.daily.map((item, idx) => (
                      <li
                        key={idx}
                        className="flex justify-between items-center"
                      >
                        <span>{item.task}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-600">{item.time}</span>
                          {item.isFixed && (
                            <span className="text-xs bg-gray-200 px-2 py-1 rounded">
                              Tetap
                            </span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          <div className="mt-6 flex justify-end space-x-4">
            <button
              onClick={() => navigate("/generate-schedule")}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
            >
              Kembali
            </button>
            {!scheduleData.hasConflict && (
              <button
                onClick={handleSave}
                disabled={isLoading}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md disabled:bg-blue-400"
              >
                {isLoading ? "Menyimpan..." : "Simpan Jadwal"}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SchedulePreview;
